import streamlit as st
import pickle
import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

nltk.download('stopwords')
nltk.download('wordnet')

model = pickle.load(open("sentiment_model_3class.pkl", "rb"))
tfidf = pickle.load(open("tfidf_3class.pkl", "rb"))

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z]', ' ', text)
    words = [lemmatizer.lemmatize(w) for w in text.split() if w not in stop_words]
    return ' '.join(words)

st.set_page_config(page_title="Sentiment Analyzer", layout="centered")

st.title("Review Sentiment Analyzer")
st.write("Predicts Negative / Neutral / Positive sentiment")

review = st.text_area("Enter a product review:")

if st.button("Predict Sentiment"):
    if review.strip() == "":
        st.warning("Please enter a review text.")
    else:
        clean_review = clean_text(review)
        vec = tfidf.transform([clean_review])
        pred = model.predict(vec)[0]

        label_map = {
            0: "Negative",
            1: "Neutral",
            2: "Positive"
        }

        if pred == 0:
            st.error(label_map[pred])
        elif pred == 1:
            st.info(label_map[pred])
        else:
            st.success(label_map[pred])